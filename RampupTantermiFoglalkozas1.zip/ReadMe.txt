Shortcut keys:
CTRL + ALT + S = Settings
CTRL + ALT + L = formazas
CTRL + ALT + O = torli az unused importokat
ALT + INSERT = Generate (konstruktor / getter /setter)
2x SHIFT = Kereses osztalyok es fajlok kozott
CTRL + F = Kereses fajlban
CTRL + R = replace text
SHIFT + F6 = refactor 
ALT + F8 = Evaluate expression (gyorsan kiertekelhetitek a metodusokat debug mode-ban)
CTRL + bal click = valtozo vagy metodus deklaraciojahoz ugrik
CTRL + W = kijelolesre (minel tobbszor nyomod meg annal tobb reszet jeloli ki a kodnak)
CTRL + SPACE = felajanlja a lehetosegeket (auto complite)
ALT + F7 = find usage (megkeresi, hogy az adott valtozo, metodus hol van meg hasznalva a projektben)



Házi feladat:
1. Az osztalyokban levo metodus es valtozokat formazd meg
2. torold a nem hasznalt importokat
3. RampUp osztalynak hoz letre a text-re getter-t a number-nek setter-t es mindkettore konstruktort
4. keresd meg az Extra class-t es a metodusban ird at a hello bello-t szia-ra
5. RampUp osztalyban a method2 metodust nevezd at methodExtra-ra
6. debug-ban nezd meg milyen exception-t dob a method2

