import java.util.ArrayList;
import java.util.List;

public class RampUp {

    private static List<Integer> lista = new ArrayList<>();

    public String getText() {
        return text;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public RampUp(int number, String text) {
        this.text = text;
        this.number = number;
    }

    private String text = "text";
    private int number = 1;

    public static void main(String args[]) {
        String textMasik = "nagyon jo ez a kurzus";
        int szam = 5;
        methodExtra();
        System.out.println("Static method: " + szam);
        methodExtra();
        methodExtra();
        System.out.println("Itt a hiba, hol a hiba: " + "Index 5 out of bounds for length 0");
    }

    public static String methodExtra() {
        try {
            lista.get(5);
        } catch (Exception e) {
            System.out.println("mi lehet a hiba?");
        }
        String text = "text2";
        return text;
    }

}
