import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ValamiNagyonJo {
    String text = "text";
    ArrayList list = new ArrayList();
    Map<String, String> map = new HashMap();

    public static void method() {
        RampUp.methodExtra();
    }
}
