package core.handler.util;

public class Extra {
    private int number = 5;
    private float singlePrecision = 5.0f;

    private void method() {
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
        System.out.println("szia");
    }
}
